#ifndef PROCESS_H
#define PROCESS_H

#include <QWidget>
#include <QTableWidget>
class Process : public QWidget
{
    Q_OBJECT

public:
    Process(QWidget *parent = 0);
    ~Process();
private:
    QTableWidget *table;
};

#endif // PROCESS_H

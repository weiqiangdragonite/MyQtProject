#include "process.h"
#include <QTableWidgetItem>
#include <windows.h>
#include <tlhelp32.h>//进程快照需要包含这个头文件
#include <QMessageBox>
Process::Process(QWidget *parent)
    : QWidget(parent)
{
    this->setWindowTitle("进程列表——秦时小——大秦皇家师范");
    table=new QTableWidget(this);
    table->setColumnCount(2);
    table->setColumnWidth(0,300);
    table->setColumnWidth(1,200);
    this->setMaximumSize(500,500);
    this->setMinimumSize(500,500);
    table->resize(this->size());
    QStringList list;
    list<<"进程名"<<"ID";
    table->setHorizontalHeaderLabels(list);
    PROCESSENTRY32 pe32;//存储进程快照的结构体
    // 在使用这个结构之前，先设置它的大小
    pe32.dwSize = sizeof(pe32);
    // 给系统内的所有进程拍一个快照
    HANDLE hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if(hProcessSnap == INVALID_HANDLE_VALUE)
    {  QMessageBox::warning(this,"提示","CreateToolhelp32Snapshot调用失败！");
    }

    // 遍历进程快照，轮流显示每个进程的信息
    else
    {
        BOOL bMore = Process32First(hProcessSnap, &pe32);//process32First 是一个进程获取函数,当我们利用函数
                                                        //CreateToolhelp32Snapshot()获得当前运行进程的快照后,
                                                        //我们可以利用process32First函数来获得第一个进程的句柄
        int i=0;
        while(bMore)
        {
            table->insertRow(i);
            //因为pe32.szExeFile的返回值是wchar_t，所以用fromWCharArray函数
            table->setItem(i,0,new QTableWidgetItem(QString::fromWCharArray(pe32.szExeFile)));
            table->setItem(i,1,new QTableWidgetItem(QString::number(pe32.th32ProcessID)));
            bMore = Process32Next(hProcessSnap, &pe32);//获取下一个进程句柄
            i++;
        }
    }
    // 不要忘记清除掉snapshot对象
    CloseHandle(hProcessSnap);


}

Process::~Process()
{

}
